#pragma once

BOOLEAN
TestFileRead(
    void
    );

void
TestFileReadPerformance(
    void
    );