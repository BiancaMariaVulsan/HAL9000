#pragma once

void
TestBitmap(
    void
    );