#pragma once

typedef QWORD       PID, *PPID;